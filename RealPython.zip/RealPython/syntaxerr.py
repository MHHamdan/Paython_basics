x = 4
y = 'x'

print(x+y)
