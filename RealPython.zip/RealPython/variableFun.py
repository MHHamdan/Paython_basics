print('My letter')

my_letter_is = 'my_letter_is: M o h a m e d'

print(my_letter_is)


