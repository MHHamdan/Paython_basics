def multiply(x, y):  #Function signature
    # Function body
    """Return the product of two numbers x and y."""

    product = x * y
    print("Me and my function ..")

    return product
    


result_multiplication = multiply(4, 7)
print(result_multiplication)

print("""Write a function called greet() that takes one string parameter
called name and displays the text "Hello <name>!", where <name> is
replaced with the value of the name parameter""")
def greet(name):
    print(f"Hello! Mr. {name}")

greet(input("Enter your Name: "))


print("""Write a function called cube() with one number parameter and returns
the value of that number raised to the third0 power. Test the
function by displaying the result of calling your cube() function on
a few different numbers.""")

def cube(x):
    return x ** 3
x = int(input("Enter your Number to be cubed :"))
print(cube(x))

