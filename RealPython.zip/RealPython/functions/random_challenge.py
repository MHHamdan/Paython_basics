import random



print(random.randint(0,1))


def coin_flip():
    """Randomly return 'heads' or 'tails'."""

    if random.randint(0, 1) == 0:
        return 'heads'
    else:
        return 'tails'


#First initialize the tallies to 0
heads_tally = tails_tally = 0

for trail in range(10_000):
    if coin_flip() == 'heads':
        heads_tally += 1
    else:
        tails_tally +=1

ratio = heads_tally / tails_tally
print(f" The ratio of heads to tails is {ratio}")


def unfair_coin_flip(probability_of_tails):
    if random.random() < probability_of_tails:
        return 'tails'
    else:
        return 'heads'

h_t = t_t = 0

for trail in range(10_000):
    if unfair_coin_flip(.7) == 'heads':
        h_t += 1
    else:
        t_t += 1

ratio = h_t / t_t
print(f"The ratio of heads to tails is {ratio}")


print("""Write a function called roll() that uses the randint() function to
simulate rolling a fair die by returning a random integer between
1 and 6.""")
def roll():
    return random.randint(1, 6)
print("Return an integer between 1, 6:   ", roll())


print("""2. Write a program that simulates 10,000 rolls of a fair die and displays
the average number rolled.""")
num_rolls = 10_000
total = 0
for trail in range(num_rolls):
    total += roll()
avg_roll = total / num_rolls

print(f"The average result of {num_rolls} rolls is {avg_roll}")

print("""Write a simulation that runs 10,000 trials of the experiment and
prints the average number of flips per trial.""")

flips = 0
num_trails = 10_000
for trail in range(num_trails):
    if coin_flip() == "heads":
        flips += 1
        while coin_flip() == 'heads':
            flips += 1
        flips += 1
    else:
        flips +=1
        while coin_flip() == 'tails':
            flips += 1
        flips += 1


avg_per_trail = flips / num_trails
print(f"The average number of flipls per trial is {avg_per_trail}.")
    

print("""Write a program that simulates the election 10,000 times and prints
the percentage of where Candidate A wins.
To keep things simple, assume that a candidate wins the election is
they win in at least two of the three regions.""")

from random import random


ali_won = ahmed_won = 0
num_trails = 10_000
for trail in range(num_trails):
    ali = ahmed = 0
    if random() < 0.87:
        ali += 1
    else:
        ahmed +=1

    if random() < .65:
        ali += 1
    else:
        ahmed +=1
    if random() < .17:
        ali +=1
        ahmed +=1

    if ali > ahmed:
        ali_won += 1
    else:
        ahmed_won += 1

print(f"Probability Ali wins: {ali_won/num_trails}")
print(f"Probability Ahmed wins: {ahmed_won/num_trails}")

