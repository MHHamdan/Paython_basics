for i in range(1, 4):
    j = i * 2
    if j % 2 == 0 :
        
        print(f"i is {i} and j is {j}")



def add_underscore(word):
    temp = '_'
    for w in word:
        temp = temp+w+'_'
    return temp

print(add_underscore(input("Enter your word: ")))
        
def add_underscores(word):
    new_word = "_"
    for i in range(len(word)):
        new_word += word[i] + "_"
    return new_word
phrase = "hello"
print(add_underscores(phrase))

def add_underscores(word):
    new_word = "_"
    for i in range(len(word)):
        new_word += word[i] + "_"
    return new_word
phrase = "hello"
print(add_underscores(phrase))

def add_underscores1(word):
    new_word = "_"
    for i in range(len(word)):
        new_word = word[i] + "_"
        print(f"i = {i}; new_word = {new_word}")
    return new_word
phrase = "Mohammed"
print(add_underscores1(phrase))
