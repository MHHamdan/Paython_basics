print(""" A ValueError occurs when an operation encounters an invalid value.
For example, trying to convert the string "not a number" to an integer
results in a ValueError:""")

#print(int('value error'))

print("""A TypeError occurs when an operation is performed on a value of the
wrong type. For example, trying to add a string and an integer will
result in a TypeError:""")

#print('1' + 1)

print("""A NameError occurs when you try to use a variable name that hasn’t
been defined yet:""")
#print(unexist_variable)

print("""A ZeroDivisionError occurs when the divisor in a division operation is
0:""")
#print(1/0)

print(""" An OverflowError occurs when the result of an arithmetic operation is
too large. For example, trying to raise the value 2.0 to the power 1_-
000_000 results in an OverflowError:""")

#print(pow(2, 1_000_000))

print(""" Sometimes you can predict that a certain exception might occur. Instead
of letting the program crash, you can catch the error if it occurs
and do something else instead.""")


while True:
    try:
        number = int(input(("Enter an integer: ")))
    except ValueError:
        print("That number was not integer")

    break


print("""You can handle multiple exception types by separating the exception
names with commas and putting the list of names in parentheses:""")

def divide(num1, num2):
    print("""In this example, the function divide() takes two parameters num1 and
num2 and prints the result of dividing num1 by num2.""")
    try:
        print(num1/num2)
    except (TypeError, ZeroDivisionError):
        print("Encounted a problem")
divide(4,0)

def divide1(num1, num2):
    print("""In this example, the function divide() takes two parameters num1 and
num2 and prints the result of dividing num1 by num2.""")
    try:
        print(num1/num2)
    except (ZeroDivisionError):
        print("Divide by zero")
    except (TypeError):
        print("Both arguments must be numbers")
divide1('t',0)

try:
    # Do lots of hazardous things that might break
    ds
    dsfs
except:
    print("Something bad happened!")

print("""Write a program that repeatedly asks the user to input an integer,
displaying a message to “try again” by catching the ValueError that
is raised if the user did not enter an integer.

Once the user enters an integer, the program should display
the number back to the user and end without crashing.""")

def display():
    
    while True:
        try:
            
            user_input = int(input("Enter an integer ...  "))
            print("Your inter is valid .. ")
            break

        except ValueError:
            print("Try again")
            
        
display()

print("""Write a program that asks the user to input a string and an integer
n. Then display the character at index n in the string.
Use error handling to make sure the program doesn’t crash
if the user does not enter an integer or the index is out of bounds.
The program should display a different message depending on
what error occurs.""")

def disply_char_at_n_position():
    string = input("Enter a string  ")
    

    try:
        num = int(input("Enter a number  "))
        print(f"{string[num]} is the character of a {string} at index {num}")

    except ValueError:
        print("You should enter a number of integer ")
    except IndexError:
        print("Index is out of range ")

disply_char_at_n_position()



