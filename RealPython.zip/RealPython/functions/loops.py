print("""The while statement starts with the while keyword, followed by a
test condition, and ends with a colon (:)

The loop body contains the code that gets repeated at each step
of the loop. Each line is indented four spaces..""")


n = 1
while n < 5:
    print(f"{n}")
    n = n + 1

num = float(input("Enter a positive number: "))

while num <= 0:
    print(f"You should enter a positive number: ")
    num = float(input('Enter a number again ... '))


print("""A for loop executes a section of code once for each item in a collection
of items. The number of times that the code is executed is determined
by the number of items in the collection.

The for statement begins with the for keyword, followed by a
membership expression, and ends in a colon (:).

The loop body contains the code to be executed at each step of
the loop, and is indented four spaces.


""")

for letter in "Python":
    print(letter)

word = "Python"

print("using while loop  ")
i = 0
while i < len(word):
    print(word[i])
    i += 1
    

print("""You can use range(n), where n is any positive number, to execute a loop
exactly n times.""")

for n in range(3):
    print("Python")

print("""You can also give a range a starting point. For example, range(1, 5)
is the range of numbers 1, 2, 3, and 4. The first argument is the starting
number, and the second argument is the endpoint, which is not
included in the range.""")

for n in range(1, 4):
    print("Pythonnnn in ragne 1 to 4 .>>> threee times")


print("""The following program asks the user
to input an amount and then displays how to split that amount between
2, 3, 4, and 5 people:""")
amount = float(input("Enter your amount: "))

for num_people in range(2, 6):
    print(f"{num_people} people: ${amount / num_people:.2f} each")



print("""As long as you indent the code correctly, you can even put loops inside
of other loops.""")
for n in range(1, 4):
    print(f"For n is {n}: ")
    for j in range(4, 7):
        print(f"j = {j} ..... ")


print("Three loops .... ")
for i in range(1,4):
    print(f"the loop number {i} in the outer 1 loop")
    for j in range(1, 4):
        print(" the loop number {} in the middle loop ".format(j))
        for h in range(1, 4):
            print("The loop {} in the inner loop :".format(h))


print("""Write a for loop that prints out the integers 2 through 10, each on
a new line, by using the range() function. \n""")
for i in range(2, 11):
    print(f"{i} the next would be the newline:\n")

print("""Use a while loop that prints out the integers 2 through 10 (Hint:
You’ll need to create a new integer first.)\n""")
i = 2
while i <= 10:
    print("{} the next number would be in below line\n".format(i))
    i += 1
    
print("""Write a function called doubles() that takes one number as its input
and doubles that number. Then use the doubles() function in a
loop to double the number 2 three times, displaying each result on
a separate line. Here is some sample output:""")

def doubles(n):
    return n ** 2

for i in range(3):
    print(f"The step {i+1} of number 2 doubled is: {doubles(2)}\n")
    
##def invest(amount, rate, years):
##    """The function then prints out the amount of the investment, rounded
##to 2 decimal places, at the end of each year for the specified number
##of years."""
##    for year in range(1, years+1):
##        print("f{amount} is your amount of the year {year} and your investment\
##               of the annual rate {rate%} is {amount+rate/100,.2f)}")
##
##print(help(invest))
##invest(int(input("Enter your amount"), int(input("Your rate:"), int(input("Years")))))
##        
##    

def invest(amount, rate, years):
    """Display year on year growth of an initial investment"""
    for year in range(1, years + 1):
        amount = amount * ( 1 + rate)
        print(f"year {year}: ${amount:,.2f}")

amount = float(input("Enter a principal amount: "))
rate = float(input("Enter an anual rate of return: "))
years = int(input("Enter a number of years: "))

invest(amount, rate, years)


x = "Hello World"
def func():
    x = 2
    print(f"Inside 'func', x has the value {x}")
    func()
    print(f"Outside 'func', x has the value {x}")

x = 5
def outer_func():
    y = 3
    def inner_func():
        z = x + y
        return z
    return inner_func()

print(outer_func())


total = 0
def add_to_total(n):
    """To avoid referrenced before assigned"""
    global total
    total += n
    print(total)

add_to_total(3)
