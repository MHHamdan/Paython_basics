print(type(True),type(False))


print(1 == 1)
print(4 != 4)

print("""For each of the following conditional expressions, guess whether
they evaluate to True or False. Then type them into the interactive
window to check your answers:""")


print(f"True for {1<=1}")
print(f"False for {1 != 1}")
print(f"True for {1 !=2}")
print(f"True for {'good'!='bad'}")

print("""For each of the following expressions, fill in the blank (indicated by
__) with an appropriate boolean comparator so that the expression
evaluates to True:""")

print(3<4)
print(10>5)
print("jack" != "jill")
print(42 == 42)

print("True "+ str(2 < 1 and 4 < 3))
print("False "+ str(1 <2 and 4< 3))


print( not True == False)


print("""Operator Order of Precedence (Highest to lowest)
<, <+, == , >=, <
not
and
or
""")

print(False == (not True))


print(True and not str((1 != 1)) +" should be True")
print((True and False) == (True and False) )

print("""Figure out what the result will be (True or False) when evaluating
the following expressions, then type them into the interactive window
to check your answers:
(1 <= 1) and (1 != 1)
not (1 != 2)
("good" != "bad") or False
("good" != "Good") and not (1 == 1)""")

print("Should be False....")
print((1 <= 1) and (1 != 1))
print("Should be False")
print(not ( 1 !=2 ))
print(f"{('good' !='Good') and not (1 == 1)} This should be False")



print("""Add parentheses where necessary so that each of the following expressions
evaluates to True:
False == not True
True and False == True and False
not True and "A" == "B """
    )

print(f"{False == (not True)} This should be True")
print("{} This should be True".format(True and False == True and False))
print(f"{(not True) and 'A' == 'B'} THis hould be False")


if 2 + 2 == 4.4:
    print("correct 2 + 2 = 4")
else:
    print("Not correct")


grade = int(input("Enter your grade ... "))
while grade <=49 or grade >100:
    grade = int(input("Enter a positive grade and less than 101:-  "))
    if grade >= 90:
        print("Excellent ... ")
    elif grade >= 80 and grade <90:
        print("Good .... ")
    elif grade >=70 and grade <80:
        print("Average ...")
    else:
        print("Fail ...")
       

sport = input("Enter a sport: ")
p1_score = int(input("Enter player 1 score: "))
p2_score = int(input("Enter player 2 score: "))

if sport.lower() == "basketball":
    if p1_score == p2_score:
        print("The game is a draw.")
    elif p1_score > p2_score:
        print("Player 1 wins.")
    else:
        print("Player 2 wins.")
# 2
elif sport.lower() == "golf":
    if p1_score == p2_score:
        print("The game is a draw.")
    elif p1_score < p2_score:
        print("Player 1 wins.")
    else:
        print("Player 2 wins.")
# 3
else:
 print("Unknown sport")


if p1_score == p2_score:
    print("The game is a draw.")
elif sport.lower() == "basketball":
    if p1_score > p2_score:
        print("Player 1 wins.")
    else:
        print("Player 2 wins.")
elif sport.lower() == "golf":
    if p1_score < p2_score:
        print("Player 1 wins.")
    else:
        print("Player 2 wins.")
else:
    print("Unknown sport.")


sport = sport.lower()
p1_win_basketball = (sport == "basketball") and (p1_score > p2_score)
p1_win_golf = (sport =="golf") and (p1_score < p2_score)

p1_wins = p1_win_basketball or p1_win_golf

if p1_wins:
    print("player 1 won ...")
else:
    print("Player 2 won ...")


sport = sport.lower()
if p1_score == p2_score:
    print("The game is a draw.")
elif (sport == "basketball") or (sport == "golf"):
    sport = sport.lower()
    p1_wins_bball = (sport == "basketball") and (p1_score > p2_score)
    p1_wins_golf = (sport == "golf") and (p1_score < p2_score)
    p1_wins = p1_wins_bball or p1_wins_golf
    if p1_wins:
        print("Player 1 wins.")
    else:
        print("Player 2 wins.")
else:
    print("Unknown sport")



print("""Write a program that prompts the user to enter a word using the
input() function and compares the length of the word to the number
five. The program should display one of the following outputs,
depending on the length of the user’s input:
• "Your input is less than 5 characters long"
• "Your input is greater than 5 characters long"
• "Your input is 5 characters long""")

word = input("Enter a word ")
if len(word) < 5:
    print("Your input is less than 5 characters long")
elif len(word) > 5:
    print("Greater...")
else:
    print("=== 5")


print("""A factor of a positive integer n is any positive integer less than or equal
to n that divides n with no remainder.""")

def factor(n):
    """A factor of a positive integer n is any positive integer less than or equal
to n that divides n with no remainder."""
    i = 1
    while i <= n:
        if n % i == 0:
            print(f"{i} is a factor of {n}")
        i +=1
#print(help(factor()))
factor(12)

sum_evens = 0
for i in range(100):
    if i % 2 == 0:
        if i == 50:
            break
        elif i >=40:
            continue
        sum_evens += i
print(sum_evens)


phrase = "it marks the spot"
for char in phrase:
    if char == "X":
        break
else:
    print("There was no 'X' in the phrase")


def passwords():
    """Here’s a practical example that gives a user three attempts to enter a
password:"""
    for i in range(3):
        print(f"Enter your {i+1} attemp of a password ")
        password = input("Enter password here .....   ")
        if password == '123abc':
            break
        print("password correct.")

    else:
        print("Suspicious activity. The authorities have been alart.")
passwords()

print("""Using break, write a program that repeatedly asks the user for some
input and only quits if the user enters "q" or "Q".""")
def ask_user_for_input():
    while True:
        user_input = input("Re Enter your input .. ")
        if user_input.upper() == 'Q':
            break
     

def ask_user_for_input1():
    while True:
        user_input = input("Re Enter your input .. ")
        if user_input.upper() != 'Q':
            continue
        else:
            break
           
      
    
ask_user_for_input()
    
ask_user_for_input1()

print("""Using continue, write a program that loops over the numbers 1 to
50 and prints all numbers that are not multiples of 3.""")
for i in range(1, 51):
    if i % 3 == 0:
        print(f" {i} / {3} is {i/3} ")
    else:
        continue
    
