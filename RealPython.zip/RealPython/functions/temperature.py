print(""" convert_cel_to_far() with one float parameter representing
degrees Celsius and returns a float representing the same
temperature in degrees Fahrenheit using the following formula:
F = C * 9/5 + 32""")

def convert_cel_to_far(c):
    """ Convert Celsius to Fahrenheit """
    return c * 9/5 + 32

def convert_far_to_cel(f):
    """ Convert Fahrenheit to Celsius """
    return (f- 32) * 5/9

c = int(input("Enter Celsius degree:  "))
print("{} is your Celsius degree \n That equivallent to {} in Fahrenheit".format(c, round(convert_cel_to_far(c),2)))


f = int(input("Enter Fehrenheit degree:  "))
print(f"{f} is your Fehrenheit degree \n That equivallent to {round(convert_far_to_cel(f),2)} in Celsius") 

