print("""A module is a file containing Python code that can be re-used in other
Python code files.
Technically, every Python script file that you have created while reading
this book is a module, but you haven’t seen how to use code from
one module inside of another.""")


print("""A namespace is a collection of names, such as variable names,
function names, and class names. Every Python module has its own
namespace.
Variables, functions, and classes in a module can be accessed from
within the same module by just typing their name. That’s how you’ve
been doing it throughout this book so far. However, this doesn’t work
for imported modules.
To access a name in an imported module from the calling module, type
the imported module’s name followed by a dot (.) and the name you
want to use:""")


from myproject import adder 


value = adder.add(2, 3)

print(value)


val = adder.mul(5,6)
print(val)




        
print("""Import Statement Variations
The import statement is flexible. There are two variations that you
should know about:
1. import <module> as <other_name>"

2. from <module> import <name>
Let’s look at each of these variations in detail.
import <module> as <other_name>
You can change the name of an import using the as keyword:
import <module> as <other_name>
When you import a module this way, the module’s namespace is accessed
through <other_name> instead of <module>.""")

from myproject import adder as d

print(d.mul(9,6), d.add(5,8))


from classes import Human

hu = Human()
print(hu)

from myproject.adder import mul as m

print(m(4,6))

from myproject.adder import *


print(add(55, 5))
print(mul(9, 8))


print("""import <module> Import all of <module>’s namespace into
the name <module>. Import module names
can be accessed from the calling module
with <module>.<name>.
import <module> as
<other_name>
Import all of <modules>’s namespace into
the name <other_name>. Import module
names can be accessed from the calling
module with <other_name>.<name>.
from <module> import
<name1>, <name2>, ...
Import only the names <name1>, <name2>,
etc, from <module>. The names are added
to the calling modules’s local namespace
and can be accessed directly.""")

print("""illustrate three of the main reasons namespaces are used:
1. They group names into logical containers
2. They prevent clashes between duplicate names
3. They provide context to names
Namespace in code provide the same advantages.
You have seen three different ways to import a module into another
one. Keeping in mind the advantages namespaces give you can help
you determine which kind of import statement makes the most sense.
In general, import <module> is the preferred way to import a module
because it keeps the imported module’s namespace completely separate
from the calling module’s namespace. Moreover, every name
from the imported module is accessed from the calling module with
the <module>.<name> format, which immediately tells you which module
the name originates in.
There are two reasons you might use the import <module> as <other_-
name> format:
1. The module name is long and you wish to import an abbreviated
version of it
2. The module name clashes with an existing name in the calling
module
import <module> as <other_name> still keeps the imported module’s
namespace separate from the calling module’s namespace. The
tradeoff is that the name you give the module might not be as easily
recognizable as the original module name.""")


print("""Importing specific names from a module is generally the least preferred
way to import code from a module. The imported names are
added directly to the calling module’s namespace, completely removing
them from context of the calling module.""")



print("""Sometimes, modules contain a single function or class that has the
same name as the module. For example, there is a module in the
Python standard library called datetime that contains a class called
datetime.
Suppose you add the following import statement to your code:
import datetime
This imports the datetime module into your code’s namespace, so in
order to use the datetime class contained in the datetime module, you
need to type the following:
datetime.datetime(2020, 2, 2)
Don’t worry about how the datetime class works right now. The
important part of this example is that having to constantly time
datetime.datetime anytime you want to use the datetime class is
redundant and tiring.
This is a great example of when it’s appropriate to use one of the variations
of the import statement. To keep the context of the datetime package,
is common for Python programmers to import the package and
rename it as dt:""")

import datetime
print(datetime.datetime(2020, 2, 3))


import datetime as dt
print(dt.datetime(2022, 3, 4))


print("""It is also common for Python programmers to import the datetime
class directly into the calling module’s namespace:
from datetime import datetime
This is fine because the context isn’t really lost. The class and the module
share the same name, after all.
When imported directly, you no longer have to use dotted module""")

from datetime import datetime
print(datetime(2020, 3, 4))


print("""The various import statements allow you to reduce typing and unnecessarily
long dotted module names. That said, abusing the various
import statements can lead to a loss of context, resulting in code that
is more difficult to understand.
Always use good judgment when importing modules so that the most
context possible is preserved.""")


print("""Create a module called greeter.py that contains a single function
greet(). This function should accept a single string parameter name
print the text Hello {name}! to the interactive window with {name}
replaced with the function argument.""")

print("""Create a module called main.py that imports the greet() function
from greet.py and calls the function with the argument "Real
Python".""")

from greeter import greet

print(greet('Real Python'))





print("""Working With Packages
Modules allow you to divide a program in to individual files that can be
reused as needed. Related code can be organized into a single module
and kept separate from other code.
Package take this organizational structure one step further by allowing
you to group related modules under a single namespace.
In this section, you’ll learn how to create your own Python package
and import code from that package into another module.""")


print("""Creating Packages
A package is a folder that contains one or more Python modules. It
must also contain a special module called __init__.py. Here is an example
of a package so that you can see this structure:""")


print("""Using your computers file explorer, or whatever tool you are comfortable
with, create a new folder somewhere on your computer called
packages_example/. Inside of that folder, create another folder called
mypackage/.Using your computers file explorer, or whatever tool you are comfortable
with, create a new folder somewhere on your computer called
packages_example/. Inside of that folder, create another folder called
mypackage/.""")


print("""The packages_example/ folder is called the project folder, or project
root folder, because it contains all of the files or folders in the
packages_examples project. The mypackage/ folder will eventually become
a Python package. It isn’t one right now because it doesn’t
contain any modules.""")







print("""Finally, create two more script windows. Save these files as module1.py
and module2.py, respectively, in your mypackages/ folder, and insert comments
at the top of each file containing the file name.
When you are done, you should have five IDLE windows open: the
interactive window and four script windows. You can arrange your
screen to look something like this:""")








