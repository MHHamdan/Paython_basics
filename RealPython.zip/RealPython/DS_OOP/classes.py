print("""Classes are used to create user-defined data structures. Classes define
functions called methods, which identify the behaviors and actions
that an object created from the class can perform with its data.""")

print("""A class is a blueprint for how something should be defined. It doesn’t
actually contain any data. The Dog class specifies that a name and an
age are necessary for defining a dog, but it doesn’t contain the name
or age of any specific dog.
While the class is the blueprint, an instance is an object that is built
from a class and contains real data. An instance of the Dog class is not
a blueprint anymore. It’s an actual dog with a name, like Miles, who’s
four years old.
Put another way, a class is like a form or questionnaire. An instance
is like a form that has been filled out with information. Just like many
people can fill out the same form with their own unique information,
many instances can be created from a single class.""")

class Dog:
    """The properties that all Dog objects must have are defined in a method
called .__init__(). Every time a new Dog object is created, .__init_-
_() sets the initial state of the object by assigning the values of the
object’s properties. That is, .__init__() initializes each new instance
of the class.
You can give .__init__() any number of parameters, but the first parameter
will always be a variable called self. When a new class instance
is created, the instance is automatically passed to the self parameter
in .__init__() so that new attributes can be defined on the
object.
Let’s update the Dog class with an .__init__() method that creates .name
and .age attributes:"""
    pass
    print("pass is excuted ..")

    species = "Canis familiearis"

    def __init__(self, name, age):
        """Notice that the .__init__() method’s signature is indented four spaces.
The body of the method is indented by eight spaces. This indentation
is vitally important. It tells Python that the .__init__() method belongs
to the Dog class.
1. self.name = name creates an attribute called name and assigns to it
the value of the name parameter.
2. self.age = age creates an attribute called age and assigns to it the
value of the age parameter.

Attributes created in .__init__() are called instance attributes. An
instance attribute’s value is specific to a particular instance of the class.
All Dog objects have a name and an age, but the values for the name and
age attributes will vary depending on the Dog instance.
On the other hand, class attributes are attributes that have the same
value for all class instances. You can define a class attribute by assigning
a value to a variable name outside of .__init__().
For example, the following Dog class has a class attribute called species
with the value "Canis familiaris":"""
        self.name = name
        self.age = age

print(Dog)

a = Dog('a', 3)
b = Dog('a', 3)
print(a == b, """  In this code, you create two new Dog objects and assign them to the
variables a and b. When you compare a and b using the == operator,
the result is False. Even though a and b are both instances of the Dog
class, they represent two distinct objects in memory.""")


print("""Now create a new Dog class with a class attribute called .species and
two instance attributes called .name and .age:""")

buddy = Dog("Buddy", 8)
miles = Dog("Miles", 4)
print(buddy.species, buddy.name, buddy.age)
print(buddy)
buddy.age = 1000
print(buddy.species, buddy.name, buddy.age)


print("""Instance Methods
Instance methods are functions that are defined inside of a class
and can only be called from an instance of that class. Just like .__-
init__(), an instance method’s first parameter is always self.""")

class Animal:
    species = " What kind of animal .. "

    def __init__(self, name, age):
        self.name = name
        self.age = age

     
    
    #Instance method
    def description(self):
        return f"{self.name} is {self.age} years old"

    # Another instance method
    def speak(self, sound):
        return f"{self.name} says {sound}"

    def __str__(self):
         return f"{self.name} is {self.age} years old and from {self.species}"

dog = Animal("hogg", 2)
#dog.speak("")

cat = Animal("Hiym", 1)
cat.speak("Mew Mew")

print(dog.description(), dog.speak('Woof Woof'))

print(cat.description(), dog.speak('Mew Mew'))

print(dog)


print("""Methods like .__init__() and .__str__() are called dunder methods
because they begin and end with double underscores. There are many
dunder methods that you can use to customize classes in Python.""")

print("""1. Modify the Dog class to include a third instance attribute called
coat_color, which stores the color of the dog’s coat as a string.
Store your new class in a script and test it out by adding the
following code at the bottom of the script:""")

class Animal:
    species = " What kind of animal .. "

    def __init__(self, name, age, coat_color):
        self.name = name
        self.age = age
        self.coat_color = coat_color

     
    
    #Instance method
    def description(self):
        return f"{self.name} is {self.age} years old"

    # Another instance method
    def speak(self, sound):
        return f"{self.name} says {sound}"

    def __str__(self):
         return f"{self.name} is {self.age} years old and from {self.species} , {self.coat_color}"

print(dog)
        
philo = Animal("Philo", 5, "brown")
print(f"{philo.name}'s coat is {philo.coat_color}.")



print("""Create a Car class with two instance attributes: .color, which stores
the name of the car’s color as a string, and .mileage, which stores
the number of miles on the car as an integer. Then instantiate
two Car objects—a blue car with 20,000 miles and a red car with
30,000 miles—and print out their colors and mileage. Your output
should look like this:""")
class Car:
    def __init__(self, color, milage):
        self.color = color
        self.milage = milage

    def __str__(self):
        print(f"Car has color {self.color} and its milage is {self.milage}")

    def drive(self, miles):
        self.milage += miles
    
car1 = Car('blue', 20_000)
car2 = Car('red', 30_000)

print(car1.color)

for car in (car1, car2):
    print(f"The {car.color} car has {car.milage:,} miles")

print("""Modify the Car class with an instance method called .drive(),
which takes a number as an argument and adds that number to
the .mileage attribute. Test that your solution works by instantiating
a car with 0 miles, then call .drive(100) and print the .mileage
attribute to check that it is set to 100.""")

print(car1.milage)
car1.milage = 0
car1.drive(100)
print(car1.milage)


class Dog:
    species = 'Canis familiaris'

    def __init__(self, name, age, bread):
        self.name = name
        self.age = age
        self.bread = bread

    def speak(self, sound):
        return (f"{self.name} speaks or barks as '{sound}'..")

    def __str__(self):
        return (f"The {self.name} his age as {self.age} ")
    
miles = Dog("Miles", 4, "From Rasia")
buddy = Dog("Miles", 5, "From US")
bd = Dog("Miles", 6, "From UK")
mi = Dog("Miles", 7, "From Yemen")
ra = Dog("Miles", 8, "From Rasia")
ue = Dog("Miles",9, "From UEA")
sa = Dog("Miles", 2, "From SA")
qa = Dog("Miles", 1, "From Qatur")


print(miles)


print("""Remember, to create a child class, you create new class with its own
name and then put the name of the parent class in parentheses. The
following creates three new child classes of the Dog class:""")

class Jack(Dog):
    pass
    print("This is a jack child")
    def speak(self, sound='Arfffffff'):
        #return f"{self.name}           saysssssssssssssssssssssssssssssss {sound}"
        return super().speak(sound)
class Dash(Dog):
    pass
    print("This is a Dash dog child ")
class Ja:
    pass
    print("This is a Dash dog child ")

class Bulldog(Dash):
    pass
    print("This is BullDog grand Chilid of Dash")


miles_ch = Dog("Miles14", 14, "From Rasia")
buddy_chi = Jack("Miles15", 15, "From US")
A = Ja()

bd_gr_ch = Bulldog("Miles16", 16, "From UK")

print(bd_gr_ch, type(bd_gr_ch))
print(isinstance(bd_gr_ch, Dog))
print(isinstance(bd_gr_ch, Ja))
print(isinstance(bd_gr_ch, Dash))

print(miles_ch.speak('hi'))


modi = Jack('Modi', 33,'MMMMMMM')
print(modi)
print(modi.speak())


        

print("""In the above examples, the class hierarchy is very simple: the
JackRussellTerrier class has a single parent class, Dog. In realworld
examples, the class hierarchy can get quite complicated.
super() does much more than just search the parent class for a
method or an attribute. It traverses the entire class hierarchy
for a matching method or attribute. If you aren’t careful, super()
can have surprising results.""")


print("""Create a GoldenRetriever class that inherits from the Dog class. Give
the sound argument of GoldenRetriever.speak() a default value o""")

class Dog:
    species = "Canis familiaris"
    def __init__(self, name, age):
        self.name = name
        self.age = age
    def __str__(self):
        return f"{self.name} is {self.age} years old"
    def speak(self, sound):
        return f"{self.name} says {sound}"


class GoldenRetriever(Dog):
    def speak(self, sound='Bark'):
        return f"{self.name} says {sound}"


obj1 = GoldenRetriever('HaveYouHave', 44)
print(obj1)
print(obj1.speak())


print("""Write a Rectangle class that must be instantiated with two attributes:
.length and .width. Add an .area() method to the class
that returns the area (length * width) of the rectangle.""")

class Rectangle:
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width
    def __str__(self):
        return f"The area of this rectangle's length {self.length} and width {self.width} is {self.area()}"  


    
    


rec = Rectangle(3, 6)
print(rec.area())

print(rec)


print("""Then write a Square class that inherits from the Rectangle class and
is instantiated with a single attribute called .side_length. Test
your Square class by instantiating a Square with a .side_length of 4.
Calling .area() should return 16.""")

class Square(Rectangle):
    def __init__(self, side_length):
        super().__init__(side_length, side_length)


sq = Square(4)
print(sq.area())


class Human:
    def __init__(self, name='Mohamed', age=34):
        self.name = name
        self.age = age

    def __str__(self):
        return(f"{self.name} is {self.age} years old ..")



print("""The focus of this assignment is less about the Python class syntax
and more about software design in general, which is highly subjective.
This assignment is intentionally left open-ended to encourage you to
think about how you would organize your code into classes.""")

print("""Before you write any code, grab a pen and paper and sketch out a
model of your farm, identifying classes, attributes, and methods.
Think about inheritance. How can you prevent code duplication?
Take the time to work through as many iterations as you feel are
necessary.""")
print("""The actual requirements are open to interpretation, but try to adhere
to these guidelines:
1. You should have at least four classes: the parent Animal class and
at least three child animal classes that inherit from Animal.
2. Each class should have a few attributes and at least one method
that models some behavior appropriate for a specific animal or all
animals—walking, running, eating, sleeping, and so on.
3. Keep it simple. Utilize inheritance. Make sure you output details
about the animals and their behaviors.""")


class Animal:
    stuff_in_belly = position = 0
    def __init__(self, name, color):
        self.name = name
        self.color = color
    def talk(self, sound=None):
        if sound is None:
            return f"Hello. I'm {self.name}!"
        return f"{self.name} says {sound}"
    def walk(self, walk_increment):
        self.position += walk_increment
        return self.position
    def run(self, run_increment):
        self.position += run_increment
        return self.position
    def feed(self):
        self.stuff_in_belly += 1
        if self.stuff_in_belly > 3:
            return self.poop()
        else:
            return f"{self.name} is eating."
    def is_hungry(self):
        if self.stuff_in_belly < 2:
            return f"{self.name} is hungry"
        else:
            return f"{self.name} is not hungry"
    def poop(self):
        self.stuff_in_belly = 0
        return "Ate too much ... need to find a bathroom"
class Dog(Animal):
    def talk(self, sound="Bark Bark!"):
        return super().talk(sound)
    def fetch(self):
        return f"{self.name} is fetching."
class Sheep(Animal):
    def talk(self, sound="Baaa Baaa"):
        return super().talk(sound)
class Pig(Animal):
    def talk(self, sound="Oink Oink"):
        return super().talk(sound)

dog = Dog("Blitzer", "yellow")
print(f"Our dog's name is {dog.name} And he's {dog.color}.")
print(f"Say something, {dog.name}. {dog.talk()} and {dog.fetch()} ")
print(f"{dog.name} is at position {dog.walk(2)}.")
print(f"{dog.name} is now at position {dog.run(4)}")
print(dog.feed())
print(dog.is_hungry())
print(dog.feed())
print(dog.feed())
print(dog.is_hungry())
print(dog.feed())
print("\n")

# Create a sheep
sheep = Sheep("Shaun", "white")

# The sheep talks!
print(sheep.talk())

# When the sheep runs, the distance is returned
print(sheep.run(2))
print(sheep.run(2))

print("\n")

# Create a pig
pig = Pig("Carl", "pink")

# Pigs love to oink!
print(pig.talk())





    
