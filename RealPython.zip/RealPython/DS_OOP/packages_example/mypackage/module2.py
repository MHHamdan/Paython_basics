#module2
def depart(name):
    return(f"Goodby, {name}!")
