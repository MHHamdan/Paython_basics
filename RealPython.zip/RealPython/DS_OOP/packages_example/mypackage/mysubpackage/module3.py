

people = ["John", "Paul", "George", "Ringo"]
