""""The __init__.py module doesn’t need to contain any code! It only
needs to exist so that Python recognizes the mypackage/ folder as a
Python package."""
