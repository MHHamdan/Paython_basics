#module1.py
def greet(name):
    return(f"Hi {name}.")
