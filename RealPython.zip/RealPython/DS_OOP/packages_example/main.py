#main.py

print("""Importing Modules From Packages
In your main.py file, add the following code:
# main.py
import mypackage""")

import mypackage.module1
import mypackage.module2

a = mypackage.module1.greet("Mohammed")
b = mypackage.module2.depart("Mohammed")

print("""When you import the mypackage module, the module1 and module2 namespaces
are not imported automatically. In order to use them, you need
to import them as well.
Change the import statement at the top of the main.py:""")

print(a)
print(b)


print("""Just like module file names, package folder names must be valid
Python identifiers. They may only contain upper and lower case
letters, numbers, and underscores (_), and they may not start
with a digit.""")

print("""As with modules, there are several variations on the import statement
that you can use when importing packages.
Import Statement Variations For Packages
There are three variations of the import statement that you learned for
importing names from modules. These three variations translate to
the following four variations for importing modules from packages:
1. import <package>
2. import <package> as <other_name>
3. from <package> import <module>
4. from <package> import <module> as <other_name>
These variations work much the same was as the counterparts for
modules.
For instance, instead of importing mypackage.module1 on one line and
mypackage.module2 on another, you can import both modules from the
package on the same line.
Change your main.py file to the following:""")


from mypackage import module1, module2
print('1  : ', module1.greet('Hamdan'))
print('2  :  ', module2.depart('Hamdan'))


print("""You can change the name of an imported module using the as keyword:
# main.py""")

from mypackage import module1 as m1, module2 as m2
print(m1.greet("Mohammed"))
print(m2.depart("Mohammed"))



print("""You can also import individual names from a package module. For instance,
you can rewrite your main.py to the following without changing
what gets printed when you save and run the module:""")


from mypackage.module1 import greet
from mypackage.module2 import depart

print(greet("Hamdan"))
print(depart("Hamdan"))


print("""Guidelines For Importing Packages
The same guidelines for importing names from modules apply to importing
modules form packages. You should prefer that imports be
as explicit as possible, so that the modules and names imported from""")


print("""the package into the calling module have the appropriate context.
In general, the following format is the most explicit:
import <package>.<module>
Then, to access names from module, you need to type something like
the following
<package>.<module>.<name>
When you encounter names that are used from the imported module,
there is no question where those names come from. But sometimes
package and module names are long, and you find yourself typing
<package>.<module> over and over again in your code.
The following format allows you to skip the package name and import
just the module name into the calling module’s namespace:
from <package> import <module>
Now you can just type <module>.<name> to access some name from the
module. While this no longer tells you from which package the name
comes from, it does keep the context of the module apparent.
Finally, the following format is generally ambiguous and should only
be used when there is no risk of importing a name from a module that
clashes with a name in the calling module:
from <package>.<module> import <name>
Now that you’ve seen how to import modules from packages, let’s take
a quick look at how to nest packages inside of other packages.""")


print("""Importing Modules From Subpackages
A package is just a folder containing one or more Python modules, one
of which must be names __init__.py, so it’s entirely possible to have
the following package structure:""")


print("""A package nested inside of another package is called a subpackage.
For example, the mysubpackage folder is a subpackage of mypackage because
it contains an __init__.py module, as well as a second module
called module3.py.""")








print("""1. In a new project folder called package_exercises/, create a package
called helpers with three modules: __init__.py, string.py, and
math.py.""")
