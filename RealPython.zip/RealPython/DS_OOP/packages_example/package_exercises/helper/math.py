#math.py
"""In the math.py module, as a function called area() that takes
two parameters called length and width and returns their product
length * width."""
def area(a,b):
    return (f"{a*b}.")
