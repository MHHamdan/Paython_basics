def shout(string):
    return f"{string.upper()}."
