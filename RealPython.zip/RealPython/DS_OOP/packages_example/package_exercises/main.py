"""In""he root proj ect folder, create a module called main.py that imports
the shout() and area() functions. Use the shout() and area()
functions to print the following output"""


from helper import string, math

print(string.shout("mohammed"))


print(math.area(4, 8))


print("""In the root project folder, create a module called main.py that imports
the shout() and area() functions. Use the shout() and area()
functions to print the following output:
THE AREA OF A 5-BY-8 RECTANGLE IS 40""")

#print(f"{string.shout(The are of a 5-by-8 rectangle is)}  {math.area(5, 8)}")

print(string.shout('The are of a 5-by-8 rectangle is'), math.area(5, 8) )
