
print(f"Tuples are ordred {(1,2,3)}")

tup1 = (1,2,3,4,5,6,4,5)
print(tup1, type(tup1))

tup2 = (1,2,'1','2')
print(tup2)
tup3 = ()
print(tup3)

print(tuple("Python for all"))


print("""Tuples and strings have a lot in common. Both are sequence types
with a finite length, support indexing and slicing, are immutable, and
can be iterated over in a loop.
The main difference between strings and tuples is that the elements
of tuples can be any kind of value you like, whereas strings can only
contain characters.""")

num = (1, 2, 3,4,5,6,7,8,'Mohammed')
print(len(num))
print(num[2])
print(num[-1])
name = 'Mohammed'
print(name[3])
print(name[-1])

vowels = ('a', 'u', 'e', 'i', 'o')
for vowel in vowels:
    print(vowel.upper())

candidates = 4.2, 6.4
print(candidates, type(candidates))

x, y = candidates
print(x, y)


name, age, occupation = "Mohammed", 34, "Programmer"
print(name, age, occupation)

info = "Mohammed", 34, "Programmer"
name1, age1, occupation1 = info[0], info[1], info[2]
print(name1, age1, occupation1)


print('o' in vowels)
print('O' in vowels)


def adder_subtracter(num1, num2):
    return (num1 + num2, num1 - num2)

result = adder_subtracter(3, 33)
print(result)


print("""Strings and tuples are just two of Python’s built-in sequence types.
Both are immutable and iterable and can be used with index and slicing
notation.""")

print("""Create a tuple literal named cardinal_numbers that holds the strings
"first", "second" and "third", in that order.""")
cardinal = ("first", "second", "third")
for car in cardinal:
    print(car)

print("""Using index notation and print(), display the string at index 1 in
cardinal_numbers.""")

for car in cardinal:
    print(car[1])

print("""Unpack the values in cardinal_numbers into three new strings
named position1, position2 and position3 in a single line of code,
then print each value on a separate line.""")

pos1, pos2, pos3 = cardinal[0], cardinal[1], cardinal[2]
print(pos1, pos2, pos3)

print("""Create a tuple called my_name that contains the letters of your name
by using tuple() and a string literal.""")
my_name = ("Mohammed",)
print(type(my_name))
my_name = tuple("Mohammed")
print(type(my_name))

print("""Check whether or not the character "x" is in my_name using the in
keyword.""")
print('x' in my_name)

print("""Create a new tuple containing all but the first letter in my_name using
slicing notation.""")

new_tuple = tuple(my_name[1:])
print(new_tuple)

color = ['red', 'yellow', 'green', 'blue', 1 ,2]
print(color, len(color), type(color))
print(list("Mohammed"))

print("""You can create
a list from a string of a comma-separated list of items using the string
object’s .split() method:""")
groceries = 'eggs, milk, cheese'
groceries_list = groceries.split(', ')
print(groceries, '\n', type(groceries), '\n' , groceries_list, type(groceries_list))


print("a;b;c".split(";"), '  split by semi-colons')
print("The quick brown fox".split(" "), " split by space")
print("abbabaabbameba7".split('ba'))


num = [1,2,3,4,5,6,7,8,9]
print(num[3:7])
print(2 in num)
for i in num:
    if i % 2 ==0:
        print(i)
    else:
        continue

name = list("mohammed hamdan")
print(name)
name[0], name[9] = 'M', 'H'
print(name)

colors = ["red", "yellow", "green", "blue"]
print(colors)
colors.insert(1, "orange")
print(colors)

colors.insert(11, "orange111")
print(colors)
print(len(colors))
colors.insert(-7, "orange1-1")
print(colors)

print(""".insert() is said to alter colors in place. This is true for all list
methods that do not return a value..insert() is said to alter colors in place. This is true for all list
methods that do not return a value..insert() is said to alter colors in place. This is true for all list
methods that do not return a value..insert() is said to alter colors in place. This is true for all list
methods that do not return a value..insert() is said to alter colors in place. This is true for all list
methods that do not return a value..insert() is said to alter colors in place. This is true for all list
methods that do not return a value.""")

color = colors.pop(-1)
print(color)
print(colors)

colors.append('Me is the favorite color')
print(colors)

colors.pop()
colors.extend(['haha', 'hi', 'oui'])
print(colors)

print("""Just like .insert() and .append(), .extend() alters the list in place.
Just like .insert() and .append(), .extend() alters the list in place.
Just like .insert() and .append(), .extend() alters the list in place.""")

colors.extend(('he','she','it', 1,2,3))
print(colors)


print("Lists of Numbers")
nums = [1,2,3,4,5,6,7,8,9,0]
summ = 0
for num in nums:
    summ += num
print(f"The summation of the {nums} list is {summ}")

print(f"The summation of the {nums} list is {sum(nums)}")

minn = 0
for num in nums:
    if minn > num:
        minn = num
    else:
        continue
        
    
print(f"The min of the {nums} list is {minn}")
print(f"The min of the {nums} list is {min(nums)}")

maxx = 0
for num in nums:
    if maxx < num:
        maxx = num
    else:
        continue

print(f"The max of the {nums} list is {maxx}")
print(f"The max of the {nums} list is {max(nums)}")


print("""List Comprehensions
Yet another way to create a list from an existing iterable is with a list
comprehension:""")


nums = (1,2,3,4,5,6,7,8,9,0)
squares = [num**2 for num in nums]
print(nums, '\n', squares)
print("""A list comprehension is a short-hand for a for loop. In the example
above, a tuple literal containing five numbers is created and assigned
to the numbers variable. On the second line, a list comprehension loops
over each number in numbers, squares each number, and adds it to a
new list called squares.""")

sq = []
sq1 = []
for num in nums:
    sq.append( num ** 2 )
    
print(sq)
sq.sort()
print(sq)

print("""List comprehensions are commonly used to convert values in one list
to a different type.""")

print("""For instance, suppose you needed to convert a list of strings containing
floating point values to a list of float objects. The following list
comprehensions achieves this:""")

str_nums = ['1.2', '2.3', '5.3', '7.3', '3.4', '7.1']
float_nums = [float(num) for num in str_nums]
print(str_nums)
print(str_nums.sort())
print(float_nums)
print(float_nums.sort())

print("""If you find yourself creating an empty list,
looping over some other iterable, and appending new items to the list,
then chances are you can replace your code with a list comprehension!""")

print('1. Create a list named food with two elements "rice" and "beans" ')
food = ['rice', 'beans']
print(food)
print('Append the string "broccoli" to food using .append().')
food.append('broccoli')
print(food)
print('Add the string "bread" and "pizza" to "food" using .extend().')
food.extend(['bread','pizza'])
print(food)
print("""Print the first two items in the food list using print() and slicing
notation.""")
print(food[0:2])
print("Print the last item in food using print() and index notation.")
print(food[-1])
print("""Create a list called breakfast from the string "eggs, fruit, orange
juice" using the string .split() method.""")

string =  "eggs, fruit, orange, juice"
breakfast = list(string.split(','))
print(breakfast, type(breakfast))

print("Verify that breakfast has three items using len().")
print(len(breakfast))

print("""Create a new list called lengths using a list comprehension that contains
the lengths of each string in the breakfast list.""")

lengths = [len(item) for item in breakfast]
print(lengths)
print(breakfast)


print("""Lists and tuples can contain values of any type. That means lists and
tuples can contain lists and tuples as values. A nested list, or nested tuple,
list or tuple contains as value int another list or tuple""")

two_lists = [[1,2,3], [5,6,7]]
print(len(two_lists))
print(two_lists[0], two_lists[1])
print(f"Soud return a 6 here ... {two_lists[1][1]}")
print(two_lists)


print("Copying object of lists")
print("""This is a quirk of object-oriented programming, but it’s by design.
When you say large_cats = animals, the large_cats and animals variables
both refer to the same object.""")
list1 = ['a','b','c']
print(list1)
list2 = list1[:]

list2.extend(('1','2'))
print(list1)
print(list2)


matrix1 = [[1, 2], [3, 4]]
matrix2 = matrix1[:]
print(matrix1)
print(matrix2)
matrix2[0] = [22,55]
print(matrix2)
matrix2[1][0] = 1000
print(matrix2)

print("""Lists have a .sort() method that sorts all of the items in ascending
order. By default, the list is sorted in alphabetical or numerical order,
depending on the type of elements in the list:""")
colors1 = []
colors = ['red', 'yellow', 'green', 'blue']
colors1.extend(colors)
colors1.sort()
print(f"{colors} and its sorted version \n {colors1}")


nums = [1,6,3,2,8,9,4,5,7,0]
print(nums)
nums.sort()

print(""".sort() has an option parameter called key that can be used to adjust
how the list gets sorted. The key parameter accepts a function, and the
list is sorted based on the return value of that function.""")
print()
print(nums)

print(""".sort() has an option parameter called key that can be used to adjust
how the list gets sorted. The key parameter accepts a function, and the
list is sorted based on the return value of that function.

""")


print("""\n \n For example, to sort a list of strings by the length of each string, you
can pass the len function to key:""")
clrs = ['red', 'blure', 'green', 'yellow', 'while', 'black' ]
print(clrs)
clrs.sort()
print(clrs)
clrs.sort(key=len)
print(clrs)

def get_second_element(item):
    return item[1]
items = [(1,4), (1,2), (1,3)]
print(items)
items.sort(key=get_second_element)


print("""Create a tuple data with two values. The first value should be the
tuple (1, 2) and the second value should be the tuple (3, 4).""")
data = ((1, 2), (3, 4))
print(items)

print(data, type(data))

print("""Write a for loop that loops over data and prints the sum of each
nested tuple. The output should look like this:""")
for i in range(len(data)):
    print(f"Row {i+1} sum: {data[i][0] + data[i][1]}")

print("""Create the following list [4, 3, 2, 1] and assign it to the variable
numbers.""")
numbers = [4, 3, 2, 1]
print(numbers)

print("""Create a copy of the numbers list using the [:] slicing notation.""")
nums = numbers[:]
print(nums)
print("Sort the numbers list in numerical order using the .sort() method.")
numbers.sort()
print(numbers)


print("Write a program that contains the following lists of lists:")
universities = [
['California Institute of Technology', 2175, 37704],
['Harvard', 19627, 39849],
['Massachusetts Institute of Technology', 10566, 40732],
['Princeton', 7802, 37000],
['Rice', 5879, 35551],
['Stanford', 19535, 40569],
['Yale', 11701, 40500]
]
print(universities)
print("""Define a function, enrollment_stats(), that takes, as an input, a list of
lists where each individual list contains three elements: (a) the name
of a university, (b) the total number of enrolled students, and (c) the
annual tuition fees.""")



def enrollment_starts(univs):
    stds = []
    fees = []

    for univ in univs:
        stds.append(univ[1])
        fees.append(univ[2])
    return stds, fees

print("""Next, define a mean() and a median() function. Both functions should
take a single list as an argument and return the mean and median of
the values in each list.""")
def mean(values):
    return sum(values)/ len(values)

def median(values):
    values.sort()
    if len(values) % 2 == 1:
        return values[int(len(values)/2)]
    else:
        return mean(values[len(values - 1) // 2], values[len(values + 1) // 2])

    
print("""Using universities, enrollment_stats(), mean(), and median(), calculate
the total number of students, the total tuition, the mean and median
of the number of students, and the mean and median tuition values.""")

totals = enrollment_starts(universities)
print("\n")
print("***" * 6)
print(f"Total students: {sum(totals[0]):,}")
print(f"Total Tuition: $ {sum(totals[1]):,}")
print(f"\nStudent mean: {mean(totals[0]):,.2f}")
print(f"\nStudent median: {median(totals[0]):,}")
print(f"\nTuition mean:   $ {mean(totals[1]):,.2f}")
print(f"Tuition median: $ {median(totals[1]):,}")
print("*****" * 6)
print("\n")



print("""In this challenge, you’ll write a program that generates poetry.
Create five lists for different word types:""")
noun = ["fossil", "horse", "aardvark", "judge", "chef", "mango",
"extrovert", "gorilla"]
verb = ["kicks", "jingles", "bounces", "slurps", "meows",
"explodes", "curdles"]
adjective = ["furry", "balding", "incredulous", "fragrant",
"exuberant", "glistening"]

preposition = ["against", "after", "into", "beneath", "upon",
"for", "in", "like", "over", "within"]

adverb = ["curiously", "extravagantly", "tantalizingly",
"furiously", "sensuously"]

print("""Randomly select the following number of elements from each list:
• 3 nouns
• 3 verbs
• 3 adjectives
• 2 prepositions
• 1 adverb
You can do this with the choice() function in the random module. This
function takes a list as input and returns a randomly selected element
of the list.""")
import random 
def make_poem():
    
    n1 = random.choice(noun)
    n2 = random.choice(noun)
    n3 = random.choice(noun)
    while n1 == n2:
        n2 = random.choice(noun)
    while n1 == n3 or n2 == n3:
        n3 = random.choice(noun)

    v1 = random.choice(verb)
    v2 = random.choice(verb)
    v3 = random.choice(verb)
    while v1 == v2:
        v2 = random.choice(verb)
    while v1 == v3 or v2 == v3:
        v3 = random.choice(verb)

        
    adj1 = random.choice(adjective)
    adj2 = random.choice(adjective)
    adj3 = random.choice(adjective)
    while adj1 == adj2:
        adj2 = random.choice(adjective)
    while adj1 == adj3 or adj2 == v3:
        adj3 = random.choice(adjective)

    prep1 = random.choice(preposition)
    prep2 = random.choice(preposition)
    while prep1 == prep2:
        prep2 = random.choice(preposition)

    adv1 = random.choice(adverb)

    if "aeiou".find(adj1[0]) != -1:
        article = "An"
    else:
        article = "A"

    poem = (
        f"{article} {adj1} {n1}\n\n"
        f"{article} {adj1} {n1} {v1} {prep1} the {adj2} {n2}\n"
        f"{adv1}, the {n1} {v2}\n"
        f"the {n2} {v3} {prep2} a {adj3} {n3}"
    )

    return poem
poem = make_poem()
print(poem)
    
    
print("""The following code creates a dictionary literal containing names of
states and their capitals:""")
capitals = {
"California": "Sacramento",
"New York": "Albany",
"Texas": "Austin",
}

print(capitals)
d = {
    'a': 1, 'b': 2, 'c': 3, 'd': 4 }
print(d)

states = (
    ("California", "Sacramento"),
    ("New York", "Albany"),
    ("Texas", "Austin"),
)

print(states, type(states))
states = dict(states)
d_capitals = dict(states)
print(d_capitals, type(d_capitals))

print({})
print(dict())

my_dic = {
    1: [1, 2, 3, 4, 5, 6],
    2: [7, 8, 9, 0, 10, 11],
    3: 'a',
    4: 'b'
    }

print(my_dic[2][3])

capitals_list = ["Sacramento", "Albany", "Austin"]
print(my_dic)
my_dic[2] = 'Mohammed'
print(my_dic)

del my_dic[2]
print(my_dic)

print("""Like lists and tuples, dictionaries are iterable. However, looping over
a dictionary is a bit different than looping over a list or tuple.""")
for key in capitals:
    print(key)


for state in states:
    print(f"The capitall of {state} is {states[state]}")


print(states.items())

for state, capital in states.items():
    print(f"The capital of {state} is {capital}")

students = {
    "Ahmed": {
        'Grade' : 88,
        'Group' : 'A'
        },
    "ali": {
        'Grade' : 33,
        'Group' : 'B'
        },
    "Naser": {
        'Grade' : 99,
        'Group' : 'c'
        },
    "bader": {
        'Grade' : 55,
        'Group' : 'A'
        },
    "Sam": {
        'Grade' : 100,
        'Group' : 'A'
        }
    }
print(students)    
for student in students:
    print(f"{student} has the highest grade {max(student)} ...")

##for std, info1, info2 in students:
##    print(f"std has the highest mark {max(info[Grade])} in group {info[Group]}... Congrat..")


print("Create an empty dictionary named captains.")
captains = {}

print("""Using the square bracket notation, enter the following data into
the dictionary, one item at a time:
'Enterprise': 'Picard'
'Voyager': 'Janeway'
'Defiant': 'Sisko'""")

captains = {
    'Enterprise': 'Picard',
'Voyager': 'Janeway',
'Defiant': 'Sisko'
    }
# Add some key-value pairs to the dictionary
captains["Enterprise"] = "Picard"
captains["Voyager"] = "Janeway"
captains["Defiant"] = "Sisko"

print("""3. Write two if statements that check if "Enterprise" and "Discovery"
exist as keys in the dictionary. Set their values to "unknown" if the
key does not exist.""")
if 'Enterprise' not in captains:
    captains['Enterprise'] = 'unknown'
if 'Discovery' not in captains:
    captains['Discovery'] = 'unknown'


for i in ["Enterprise" , "Discovery"]:
    if i not in captains:
        captains[i] = 'unknown'


print("""Write a for loop to display the ship and captain names contained
in the dictionary. For example, the output should look something
like this:""")
for ship, captain in captains.items():
    print(f"The {ship} is captained by {captain}.")
    
print("""5. Delete "Discovery" from the dictionary.
6. Bonus: Make the same dictionary by using dict() and passing in
the initial values when you first create the dictionary.""")

del captains['Discovery']
captains_dic = dict(
        [
        ("Enterprise", "Picard"),
        ("Voyager", "Janeway"),
        ("Defiant", "Sisko"),
    ]
)


print("""Review your state capitals along with dictionaries and while loops!
First, finish filling out the following dictionary with the remaining
states and their associated capitals in a file called capitals.py.""")

capitals_dict = {
    "Alabama": "Montgomery",
    "Alaska": "Juneau",
    "Arizona": "Phoenix",
    "Arkansas": "Little Rock",
    "California": "Sacramento",
    "Colorado": "Denver",
    "Connecticut": "Hartford",
    "Delaware": "Dover",
    "Florida": "Tallahassee",
    "Georgia": "Atlanta",
    "Hawaii": "Honolulu",
    "Idaho": "Boise",
    "Illinois": "Springfield",
    "Indiana": "Indianapolis",
    "Iowa": "Des Moines",
    "Kansas": "Topeka",
    "Kentucky": "Frankfort",
    "Louisiana": "Baton Rouge",
    "Maine": "Augusta",
    "Maryland": "Annapolis",
    "Massachusetts": "Boston",
    "Michigan": "Lansing",
    "Minnesota": "Saint Paul",
    "Mississippi": "Jackson",
    "Missouri": "Jefferson City",
    "Montana": "Helena",
    "Nebraska": "Lincoln",
    "Nevada": "Carson City",
    "New Hampshire": "Concord",
    "New Jersey": "Trenton",
    "New Mexico": "Santa Fe",
    "New York": "Albany",
    "North Carolina": "Raleigh",
    "North Dakota": "Bismarck",
    "Ohio": "Columbus",
    "Oklahoma": "Oklahoma City",
    "Oregon": "Salem",
    "Pennsylvania": "Harrisburg",
    "Rhode Island": "Providence",
    "South Carolina": "Columbia",
    "South Dakota": "Pierre",
    "Tennessee": "Nashville",
    "Texas": "Austin",
    "Utah": "Salt Lake City",
    "Vermont": "Montpelier",
    "Virginia": "Richmond",
    "Washington": "Olympia",
    "West Virginia": "Charleston",
    "Wisconsin": "Madison",
    "Wyoming": "Cheyenne",
}

print("""Then display the name of the state to the user and ask them to enter
the capital. If the user answers, incorrectly, repeatedly ask them for
the capital name until they either enter the correct answer or type the
word “exit”.
If the user answers correctly, display "Correct" and end the program.""")

print(capitals_dict.items())
      
state, capital = random.choice(list(capitals_dict.items()))
print(state)
print(capital)
while True:
    guess = input(f"What is the capital of '{state}'? ".lower())
    if guess == 'exit':
        print(f" The capital of '{state}' is {capital}.")
        print("Goodby")
        break
    elif guess.lower() == capital.lower():
        print("Correct! nice job.")
        break

print("""One day you decide to arrange all your cats in a giant circle. Initially,
none of your cats have any hats on. You walk around the circle 100
times, always starting at the same spot, with the first cat (cat # 1). Every
time you stop at a cat, you either put a hat on it if it doesn’t have
one on, or you take its hat off if it has one on.
1. The first round, you stop at every cat, placing a hat on each one.
2. The second round, you only stop at every second cat (#2, #4, #6,
#8, etc.).
3. The third round, you only stop at every third cat (#3, #6, #9, #12,
etc.).
4. You continue this process until you’ve made 100 rounds around
the cats (e.g., you only visit the 100th cat).
Write a program that simply outputs which cats have hats at the end.""")


def get_cats_with_hats(array_of_cats):
    cats_with_hats_on = []
    for num in range(1, 101):
        for cat in range(1, 101):
            if cat % num ==0:
                if array_of_cats[cat] is True:
                    array_of_cats[cat] = False
                else:
                    array_of_cats[cat] = True
    for cat in range(1, 101):
        if cats[cat] is True:
            cats_with_hats_on.append(cat)
    return cats_with_hats_on

cats = [False] * (101)
print(get_cats_with_hats(cats))


num_of_cats = 101 # Since we want to loops from 0 to 100
cats_with_hats = []
num_of_laps = 101 # since the range of for loop minuse 1
for lap in range(1, num_of_laps):
    for cat in range(1, num_of_cats):
        if cat % lap == 0:
            if cat in cats_with_hats:
                cats_with_hats.remove(cat)
            else:
                cats_with_hats.append(cat)

print(cats_with_hats)

theCats = {}

for i in range(1, 101):
    theCats[i] = False

for i in range(1, 101):
    for cats, hats in theCats.items():
        if cats % i == 0:
            if theCats[cats]:
                theCats[cats] = False
            else:
                theCats[cats] = True

s = c = 0
for cats, hats in theCats.items():
    if theCats[cats]:
        c +=1
        print(f"Cat {cats} has a hat. sum is {c}")
    else:
        s +=1
        print(f"Cat {cats} is hatless! sum is {s}")


