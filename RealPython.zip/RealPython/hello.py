print(Hello)

x = 5
y = 0

z = x/y

print(z)

