#variable inspecting display th evalue as it appears in the codei

x = 123
y = '123'

print(x,y)
