hello = 'Hello World' # inline comment 
#block comment
print(hello)


##To add more comments just ctrl + D in ubuntu
##To remove a comment ust ctrl shift D
